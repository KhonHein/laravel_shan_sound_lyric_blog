<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class userAjaxController extends Controller
{
//     // add unlike conunt
//     public function addUnlike(Request $request){
//         $data = [
//             'unlike_count' =>$request->countNumber,
//          ];
//          logger($data);
//          Post::where('id',$request->postId)->update($data);
//          return response()->json();
//    }
}
