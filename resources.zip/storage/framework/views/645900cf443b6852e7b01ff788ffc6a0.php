<?php $__env->startSection('mainContent'); ?>
<!--Main Section Start-->
    <div class="bg-secondary row d-flex justify-content-center">
            <div class="col-lg-6 text-center text-lg-start ">
                <button class="btn btn-dark m-1" onclick="history.back()">
                    <i class="fa-solid fa-left-long" class="backArrow"></i>
                </button>
                <?php if($post->image !== null ): ?>
                <img class="img-fluid hoverOver  img-thumbnail border border-white" src="<?php echo e(asset( 'storage/'.$post->image)); ?>" alt="">
                <?php else: ?>
                    <?php if(Auth::user()->gender === 'male'): ?>
                        <img class="img-fluid hoverOver" src="<?php echo e(asset('img/coverImg.png')); ?>" alt="">
                        <?php elseif(Auth::user()->gender ==='female'): ?>
                        <img class="img-fluid hoverOver" src="<?php echo e(asset('img/femaleCover.png')); ?>" alt="">
                        <?php elseif(Auth::user()->gender === null): ?>
                        <img class="img-fluid hoverOver" src="<?php echo e(asset('img/null.png')); ?>" alt="">
                    <?php endif; ?>
                <?php endif; ?>

                <p class="text-black fw-bold"><?php echo e($post->title); ?></p>
                <audio src="<?php echo e(asset('storage/'.$post->sound)); ?>" controls class="mx-3 my-2"></audio>

                <div class="form-control bg-secondary">
                    <?php $__errorArgs = ['postCategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><label for="selectCategory" class="text-danger fw-bold fs-6"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="selectCategory" class="m-2 text-black fw-bold">Select category</label>
                    <select name="postCategory" id="selectCategory" class="rounded-3">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->category_name); ?>"
                            <?php if($post->category == $c->category_name): ?> selected
                            <?php endif; ?> class="form-control" >
                            <?php echo e($c->category_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <label for="status" class="m-2 text-black fw-bold">Visillabe</label>
                    <select name="postStatus" id="status" class="rounded-3">
                        <option value="free" class="form-control">free</option>
                        <option value="pro" class="form-control">pro</option>
                    </select>
                </div>
            </div>
            <div class="my-3 mx-auto d-flex justify-content-center">
                <!-- like -->
                <i id="likeIcon" onclick="clickLikeButton()" class="hoverOver fs-2 fw-bold fa-regular fa-heart"></i>
                <small class="kissedIcon mt-2 mr-2 hideDiv"><i class="fa-solid fa-face-kiss-wink-heart"></i></small>
                <p class="pLcountText mx-1" style="display:inline-block"><?php echo e($post->like_count); ?></p>
                <input type="hidden" name="" class="postLikeCount" value="<?php echo e($post->like_count); ?>">

                <!-- unlike -->
                <i id="unlike" onclick="clickUnlikeButton()" class="hoverOver fa-regular fs-2 ms-5 fa-thumbs-down"></i>
                <small class="angryIocon hideDiv mt-2 mr-2 "><i class="text-danger fa-regular fa-face-angry"></i></small>
                <p class="pULcountText text-black" style="display:inline-block"><?php echo e($post->ulike_count); ?></p>
                <input type="hidden" name="" class="postULikeCount" value="<?php echo e($post->ulike_count); ?>">

                <!-- comment -->
                <i id="comIcon" onclick="clickCommentIcon()" class="hoverOver fa-regular fs-2 ms-5 fa-comment-dots"></i>

                <!-- viwe vount-->
                <input type="hidden" id="viewCount" value="<?php echo e($post->view_count); ?>">
                <span class="viewCountText d-flex text-black ms-3"><?php echo e($post->view_count); ?></span>
                <i class="fa-solid fa-eye-slash text-black fw-bold mt-1"></i>
            </div>  <!-- comment  box -->

            <form class="commentBox hideDiv m-auto">
                <div class="d">
                    <input type="text" id="commentInput" onchange="sendcomment()" class="form-control d-inline-block bg-secondary justify-content-center" style="width:400px;">
                    <i id="sendIcon " onclick="sendcomment()" class="fa-regular text-primary fa-paper-plane fs-4"></i>

                    <input type="hidden" class="postId" value="<?php echo e($post->id); ?>">
                    <input id="userCommentId" type="hidden" value="<?php echo e(Auth::user()->id); ?>">
                    <input id="userCommentName" type="hidden" value="<?php echo e(Auth::user()->name); ?>">

                    <!-- comments-->
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-control bg-secondary my-1">
                        <strong class=" my-2 text-black fs-6"> <?php echo e($cmt->user_name); ?> </strong>
                        <p class=" my-2 mx-1 text-black fs-6"> <?php echo e($cmt->comment_message); ?> </p>
                        <a href="<?php echo e(route('user#deleteCommetn',$cmt->id)); ?>" class="deleteCommentIcon">
                            <i class="fa-solid fa-trash mx-2 fs-5"></i>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </form>

        <div class="">
            <h5 class="text-black text-center"><?php echo e($post->title); ?></h5>
            <p class="text-black "><?php echo e($post->description); ?></p>
        </div>
    </div>

<!--Main Section end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
            $postId =$(`#postId`).val();
            $viewCount = Number($('#viewCount').val());

            $viewCount = $viewCount + 1;
            $('.viewCountText').html($viewCount);
            $data={
                'countNumber' : $viewCount,
                'postId' : $postId
            };

            $.ajax({
                type: 'get',
                url : 'http://127.0.0.1:8000/user/Ajax/view_count',
                data: $data,
                dataType:'json',
                success:'response'
            })
    });
</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp1\htdocs\my-passive-income\my_education\resources\views/user/details.blade.php ENDPATH**/ ?>