<?php $__env->startSection('mainContent'); ?>
<!--Main Section Start-->
<div class="container-xxl py-5 mb-5">
    <button class="btn btn-dark ms-4" onclick="history.back()"><i class="fa-solid fa-left-long" class="backArrow"></i></button>
    <div class="container my-5 py-5 px-lg-5 w3-container w3-center w3-animate-zoom">
        <?php if(Session::has('changedProfile')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Dear <?php echo e(Auth::user()->name); ?> !</strong><?php echo e(Session::get('changedProfile')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(Session::has('updateSuccess')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Dear <?php echo e(Auth::user()->name); ?> !</strong><?php echo e(Session::get('updateSuccess')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(Session::has('confirmFail')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Dear <?php echo e(Auth::user()->name); ?> !</strong><?php echo e(Session::get('confirmFail')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        
        <?php $__errorArgs = ['newPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Dear!.<?php echo e(Auth::user()->name); ?> </strong> <?php echo e($message); ?>

            <button type="button" class="btn bg-white btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['confirmPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Dear!.<?php echo e(Auth::user()->name); ?> </strong> <?php echo e($message); ?>

            <button type="button" class="btn bg-white btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['oldPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-warning fade show" role="alert">
            <strong>Dear!.<?php echo e(Auth::user()->name); ?> </strong> <?php echo e($message); ?>

            <button type="button" class="btn bg-white btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <form class="row g-5 py-5" action="<?php echo e(route('user#profileEdit')); ?>" method="POST" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="col-lg-6 text-center text-lg-start">
                <?php if(Auth::user()->image != null ): ?>
                <img class="img-fluid previewImage ppImage border border-1 img-thumbnail border border-white" src="<?php echo e(asset( 'storage/'.Auth::user()->image)); ?>" alt="">
                <?php else: ?>
                    <?php if(Auth::user()->gender === 'male'): ?>
                        <img class="img-fluid previewImage ppImage  border border-1" src="<?php echo e(asset('img/coverImg.png')); ?>" alt="">
                        <?php elseif(Auth::user()->gender ==='female'): ?>
                        <img class="img-fluid previewImage ppImage  border border-1" src="<?php echo e(asset('img/femaleCover.png')); ?>" alt="">
                        <?php elseif(Auth::user()->gender === null): ?>
                        <img class="img-fluid previewImage ppImage  border border-1" src="<?php echo e(asset('img/null.png')); ?>" alt="">
                    <?php endif; ?>
                <?php endif; ?>
                <input type="file" name="userImage" onchange="previewImage()" class="inputPreviewImage  border  rounded-5 my-2 mx-auto d-flex justify-content-center form-control bg-secondary" style="width:200px; height:auto;">
            </div>
            <div class="col-lg-6 text-center text-lg-start">


                <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><strong class="text-danger"><?php echo e($message); ?></strong></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" name="userName" class="text-black mb-4 form-control bg-secondary" value="<?php echo e(old('userName',Auth::user()->name)); ?>">

                <?php $__errorArgs = ['userEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><strong class="text-danger"><?php echo e($message); ?></strong></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="email" name="userEmail" class="text-black pb-3 mb-4 animated zoomIn form-control bg-secondary" value="<?php echo e(old('userEmail',Auth::user()->email)); ?>">

                <?php $__errorArgs = ['userAddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><strong class="text-danger"><?php echo e($message); ?></strong></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" name="userAddress" class="text-black pb-3 mb-4 animated zoomIn form-control bg-secondary" value="<?php echo e(old('userAddress',Auth::user()->address)); ?>">

                <?php $__errorArgs = ['userPhone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><strong class="text-danger"><?php echo e($message); ?></strong></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="number" name="userPhone" class="text-black pb-3 mb-4 animated zoomIn form-control bg-secondary" value="<?php echo e(old('userPhone',Auth::user()->phone)); ?>">

                <label for="userId">User Id</label>
                <input type="text" disabled class="my-2 rounded border text-black animated zoomIn bg-secondary" name="userId" id="userId" value="<?php echo e(Auth::user()->id); ?>">

                <select name="userGender" id="" class="form-control bg-secondary">
                    <option class="form-control m-1" <?php if(Auth::user()->gender ==='male'): ?> selected <?php endif; ?>  value="male">Male</option>
                    <option class="form-control m-1" <?php if(Auth::user()->gender ==='female'): ?> selected <?php endif; ?>  value="female">Female</option>
                </select>
                <p class="text-white mb-1 pb-3  zoomIn"><?php echo e(Auth::user()->role); ?></p>

                <button type="submit" class="btn btn-outline-warning py-sm-3 px-sm-5 rounded-pill animated slideInRight">Save</button>
                <span onclick="showPassDiv()" class="btn btn-light py-sm-3 px-sm-5 rounded-pill me-1 updatePassBtn">Update Password</span>
            </div>
        </form>

       <form action="<?php echo e(route('logout')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline-danger d-flex justify-content-center py-sm-3 px-sm-5 rounded-pill animated slideInRight">Loggout</button>
       </form>

        <form action="<?php echo e(route('user#passwordUpdate')); ?>" method="POST" id="passEditDiv" class="hideDiv form-control justify-content-center rounded-5 text-center">
            <?php echo csrf_field(); ?>
            <div class=" text-center">
                <button id="closePassword" class="btn btn-close btn-success btn-outline-danger"></button>
            </div>
            <label class="text-warning" for="newPassword">Add new Password</label>
            <input type="password" name="newPassword" id="newPassword" class="form-control bg-transparent border-light p-3 text-white" placeholder="Type new password">

            <label for="confirmPassword" class="text-warning">Confrim Password</label> <?php $__errorArgs = ['confirmPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <label for="confirmPassword" class="text-danger fw-bold"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="password" name="confrimPassword" id="confirmPassword" class="form-control bg-transparent border-light p-3 text-white" placeholder="Type new password">

            <label for="oldPassword" class="text-warning">Confrim Old Password</label> <?php $__errorArgs = ['oldPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <label for="oldPassword" class="text-danger fw-bold"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="password" name="oldPassword" id="oldPassword" class="form-control bg-transparent border-light p-3 text-white" placeholder="Type new password">

            <button id="editPass" type="submit" class=" m-auto form-control-outline-light my-2 py-sm-3 px-sm-5 rounded-pill">Edit and Save</button>
        </form>
    </div>
</div>
<!--Main Section end -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp1\htdocs\my-passive-income\my_education\resources\views/user/profile.blade.php ENDPATH**/ ?>