<?php $__env->startSection('mainContent'); ?>
        <?php if($posts->count() == 0): ?>
        <div class="col-lg-3 col-md-4 col-sm-5 m-auto p-1 hoverOverTheImage">
            <h4 class="my-5 text-center">There is no post</h4>
        </div>
        <?php else: ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('user#postDetails',$p->id)); ?>" class="myElement col-sm-6 col-md-4 col-lg-3 border border-left-0  rounded-2 m-2 justify-content-center text-center rightContentChildCiv hoverOver">
                <?php if($p->image != null): ?>
                <img class="listImg rounded mt-1" src="<?php echo e(asset('storage/'.$p->image)); ?>" alt="" srcset="">
                <?php else: ?>
                    <?php if(Auth::user()->gender === 'female'): ?>
                    <img class="listImg rounded mt-1" src="<?php echo e(asset('img/femalePostDefault.jpg')); ?>" alt="" srcset="">
                    <?php elseif(Auth::user()->gender === 'male'): ?>
                    <img class="listImg rounded mt-1" src="<?php echo e(asset('img/malePostDefault.png')); ?>" alt="" srcset="">
                    <?php else: ?>
                    <img class="listImg rounded mt-1" src="<?php echo e(asset('img/null.png')); ?>" alt="" srcset="">
                    <?php endif; ?>
                <?php endif; ?>
                <p class="text-black fw-bold shanniFont fs-4"><?php echo e($p->title); ?></p>
                <audio src="<?php echo e(asset('storage/'.$p->sound)); ?>" controls class="my-2 ms-0 myAudio" type="audio/mpeg" style="width:250px; height:30px;"></audio>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stop_at_nothing\resources\views/user/index.blade.php ENDPATH**/ ?>