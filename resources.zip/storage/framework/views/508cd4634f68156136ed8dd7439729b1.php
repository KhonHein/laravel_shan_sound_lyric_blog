<?php $__env->startSection('title','Heillo Shanni'); ?>
<?php $__env->startSection('cssLink'); ?>
<!-- <link href="<?php echo e(asset('css/admin/home.css')); ?>" rel="stylesheet"> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--Main Section Start-->
<div class="containerHome">
            <div class="left-pane border border-dark">
              <!-- Content for left pane goes here -->
             <div class="container">
                <nav class="stickyNavbar">
                <button class=" mx-auto btn btn-danger btn-sm text-black fw-bold tex-center" onclick="history.back()"><i class="fa-solid fa-left-long"></i></button>
                <button class="btn btn-dark m-2 " onclick="history.back()">Back</button>
                </nav>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('admin#electByCategory',$c->category_name)); ?>" onclick="showByCategory()" class="selectByCategory shadow-sm btn btn-secondary border rounded-4 my-2 d-block " ><p class="shanniFont fs-4"><?php echo e($c->category_name); ?></p></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </div>

            </div>
            <div class="right-pane ">

                    <!-- content session-->
                <div class="show-post-div container-fluid justify-content-around d-flex row mx-auto my-2">
                    <?php if($posts->count() == 0): ?>
                        <div class="col-lg-3 col-md-4 col-sm-5 m-auto p-1 hoverOverTheImage">
                            <h4 class="my-5 text-center ">There is no post</h4>
                        </div>
                    <?php else: ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin#postDetails',$p->id)); ?>" class="myElement col-sm-6 col-md-4 col-lg-3 border border-left-0  rounded-2 m-2 justify-content-center text-center rightContentChildCiv hoverOver">
                        <?php if($p->image != null): ?>
                        <img class="listImg rounded mt-1" src="<?php echo e(asset('storage/'.$p->image)); ?>" alt="" srcset="">
                        <?php else: ?>
                            <?php if(Auth::user()->gender === 'female'): ?>
                            <img class="listImg rounded mt-1" src="<?php echo e(asset('img/femalePostDefault.jpg')); ?>" alt="" srcset="">
                            <?php elseif(Auth::user()->gender === 'male'): ?>
                            <img class="listImg rounded mt-1" src="<?php echo e(asset('img/malePostDefault.png')); ?>" alt="" srcset="">
                            <?php else: ?>
                            <img class="listImg rounded mt-1" src="<?php echo e(asset('img/null.png')); ?>" alt="" srcset="">
                            <?php endif; ?>
                        <?php endif; ?>
                        <p class="text-black fw-bold shanniFont fs-4 text-decoration-none"><?php echo e($p->title); ?></p>
                        <audio src="<?php echo e(asset('storage/'.$p->sound)); ?>" controls class="my-2 myAudio" type="audio/mpeg" style="width:200px; height:30px;"></audio>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php endif; ?>
                </div>

                <!-- Full Screen Search Start -->
                <form action="<?php echo e(route('admin#homePage')); ?>" method="GET"  class="modal fade" id="goToSearchModal" tabindex="-1">
                    <div class="modal-dialog modal-fullscreen">
                        <div class="modal-content" style="background: rgba(29, 29, 39, 0.7);">
                            <div class="modal-header border-0">
                                <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body d-flex align-items-center justify-content-center">
                                <div class="input-group" style="max-width: 600px;">
                                    <input name="key" type="text" class="form-control text-white fs-4 bg-transparent border-light p-3 shanniFont " placeholder="wFrfBcMj">
                                    <button type="submit" class="btn btn-primary px-4"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <!-- Full Screen Search End -->

            </div>
        </div>
<!--Main Section end -->
<?php $__env->stopSection(); ?>






<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stop_at_nothing\resources\views/admin/home.blade.php ENDPATH**/ ?>