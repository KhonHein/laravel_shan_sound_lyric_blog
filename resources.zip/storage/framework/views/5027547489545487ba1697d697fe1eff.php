<?php $__env->startSection('title','AdminDashboard'); ?>
<?php $__env->startSection('content'); ?>
<!--Main Section Start-->
<div class="container-xxl py-5 mb-5">
    <button class="btn btn-dark ms-4" onclick="history.back()"><i class="fa-solid fa-left-long" class="backArrow"></i></button>
    <div class="container my-5 py-5 px-lg-5 w3-container w3-center w3-animate-zoom">
        <div class="row g-5 py-5">
                <table>
                    <tr>
                        <th>id</th>
                        <th>Image</th>
                        <th>name</th>
                        <th>email</th>
                        <th>address</th>
                        <th>phone</th>
                        <th>gender</th>
                        <th>role</th>
                        <th></th>
                    </tr>
                    <tbody>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('ajax#changeRole')); ?>" method="POST" class="row g-5 py-5 d-flex">
                         <?php echo csrf_field(); ?>
                        <tr class="my-2">
                            <input type="hidden" name="user_id_role" value="<?php echo e($u->id); ?>">
                            <td><?php echo e($u->id); ?></td>
                            <td>
                                <?php if($u->image !== null): ?>
                                <img class="img-fluid border rounded-5 mouseHoverCSS"  src="<?php echo e(asset('storage/'.$u->image )); ?>" alt="" srcset="" style="width:40px; height:40px;">
                                <?php else: ?>
                                    <?php if($u->gender === 'male'): ?>
                                        <img class="img-fluid border rounded-5 mouseHoverCSS" src="<?php echo e(asset('img/coverImg.png')); ?>" alt="" style="width:40px; height:40px;">
                                        <?php elseif($u->gender ==='female'): ?>
                                        <img class="img-fluid  border rounded-5 mouseHoverCSS" src="<?php echo e(asset('img/femaleCover.png')); ?>" alt="" style="width:40px; height:40px;">
                                        <?php elseif($u->gender === null): ?>
                                        <img class="img-fluid  border rounded-5 mouseHoverCSS" src="<?php echo e(asset('img/null.png')); ?>" alt="" style="width:40px; height:40px;">
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($u->name); ?></td>
                            <td><?php echo e($u->email); ?></td>
                            <td><?php echo e($u->address); ?></td>
                            <td><?php echo e($u->phone); ?></td>
                            <td><?php echo e($u->gender); ?></td>
                            <td>
                                <select name="userRole" class="changeRoleSelect" onchange="changeRoleFun()">
                                        <option class="form-control"  value="admin" <?php if($u->role == 'admin'): ?> selected <?php endif; ?> >admin</option>
                                        <option class="form-control"  value="pro" <?php if($u->role == 'pro'): ?> selected <?php endif; ?> >pro</option>
                                        <option class="form-control"  value="user" <?php if($u->role == 'user'): ?> selected <?php endif; ?> >user</option>
                                </select>
                            </td>
                            <td>
                                <?php if($u->role === Auth::user()->role): ?>
                                <button type="submit" class="btn btn-sm btn-dark" disabled>me</button>
                                <?php else: ?>
                                <button type="submit" class="btn btn-sm btn-dark">change</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
        </div>
    </div>
</div>

<!--Main Section end -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stop_at_nothing\resources\views/admin/changeRole.blade.php ENDPATH**/ ?>