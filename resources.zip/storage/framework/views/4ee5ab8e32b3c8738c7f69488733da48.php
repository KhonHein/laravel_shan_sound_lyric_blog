
<?php $__env->startSection('title','AdminDashboard'); ?>
<?php $__env->startSection('content'); ?>
<!--Main Section Start-->
<div class="container-xxl py-2 mb-2">
    <button class="btn btn-dark ms-4" onclick="history.back()"><i class="fa-solid fa-left-long" class="backArrow"></i></button>
    <div class="container my-2 py-2 px-lg-5 w3-container w3-center w3-animate-zoom">
        <div class="row g-5 py-2">
        <?php if(Session::has('updateSuccess')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Dear <?php echo e(Auth::user()->name); ?> !</strong><?php echo e(Session::get('updateSuccess')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
                <table>
                    <tr>
                        <th class=" m-2 text-black fw-bold">Id</th>
                        <th class=" m-2 text-black fw-bold">Category name</th>
                        <th class=" m-2 text-black fw-bold"> dEit/Update</th>
                        <th></th>
                    </tr>
                    <tbody>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('admin#updateCategory')); ?>" method="POST" class="row g-5 py-5 d-flex">
                         <?php echo csrf_field(); ?>
                        <tr class="my-2">
                            <td class =" m-2 text-black fw-bold m-2 text-black fw-bold shanniFont fs-4"><?php echo e($c->id); ?></td>
                            <td class =" m-2 text-black fw-bold m-2 text-black fw-bold shanniFont fs-4"><?php echo e($c->category_name); ?></td>
                            <td class =" m-2 text-black fw-bold m-2 text-black fw-bold  fs-4">
                                <input name="categoryName" class="m-2 text-black border rounded-3 shanniFont fs-4 fw-bold" value="<?php echo e($c->category_name); ?>" style="width:150px;" required />
                                <button type=""submit class="btn btn-dark btn-outline-danger">save&change</button>
                            </td>
                            <input name="categoryId" type="hidden" value<?php echo e($c->id); ?>/>
                        </tr>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
        </div>
    </div>
</div>

<!--Main Section end -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stop_at_nothing\resources\views/admin/category_list.blade.php ENDPATH**/ ?>